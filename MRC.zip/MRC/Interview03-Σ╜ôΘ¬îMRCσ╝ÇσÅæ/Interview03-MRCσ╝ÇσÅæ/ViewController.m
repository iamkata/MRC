//
//  ViewController.m
//  Interview03-MRC开发
//
//  Created by MJ Lee on 2018/6/27.
//  Copyright © 2018年 MJ Lee. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()
@property (retain, nonatomic) NSMutableArray *data;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
//    //刚开始我们这么写
//    NSMutableArray *data = [[NSMutableArray alloc] init];
//    self.data = data;
//    [data release];
//
//    //后来简化
//    self.data = [[NSMutableArray alloc] init];
//    [self.data release];
//
//    //后来又简化
//    self.data = [[[NSMutableArray alloc] init] autorelease];
    
    //最后还可以这样写
    //Foundation框架，一般使用类方法创建的对象，内部都已经调用了autorelease
    //也可以这样想：array方法没看到alloc，所以不用release
    self.data = [NSMutableArray array];
}

//一定要释放
- (void)dealloc {
    self.data = nil;
    
    [super dealloc];
}

@end

//
//  main.m
//  Interview01-内存管理
//
//  Created by MJ Lee on 2018/6/27.
//  Copyright © 2018年 MJ Lee. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MJPerson.h"
#import "MJDog.h"

//为什么要retain新值
void test2()
{
    MJDog *dog = [[MJDog alloc] init]; // dog：1

    MJPerson *person1 = [[MJPerson alloc] init]; // person1：1
    [person1 setDog:dog]; // dog：2
    
    MJPerson *person2 = [[MJPerson alloc] init];  // person2：1
    [person2 setDog:dog]; // dog：3

    [dog release]; // dog：2

    [person1 release]; // person1：0  dog：1

    [[person2 dog] run];
    [person2 release];   // person2：0 dog：0
}
//达到的效果：就是只要有人使用狗，狗就不会销毁，这也是我们想要的效果。

//为什么要release旧值
void test3()
{
    MJDog *dog1 = [[MJDog alloc] init]; // dog1 : 1
    MJDog *dog2 = [[MJDog alloc] init]; // dog2 : 1

    MJPerson *person = [[MJPerson alloc] init]; // person : 1
    [person setDog:dog1]; // dog1 : 2
    [person setDog:dog2]; // dog2 : 2, dog1 : 1

    [dog1 release]; // dog1 : 0
    [dog2 release]; // dog2 : 1
    [person release]; //person : 0 dog2 : 0
}

//判断新值和旧值是否一样
//打开僵尸对象：已经死掉的对象
void test4()
{
    MJDog *dog = [[MJDog alloc] init]; // dog:1

    MJPerson *person = [[MJPerson alloc] init]; // person : 1
    [person setDog:dog]; // dog:2

    [dog release]; // dog:1

    [person setDog:dog];//旧值新值一样，不做任何事
    [person setDog:dog];
    [person setDog:dog];

    [person release]; // person : 0  dog : 0
}

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        test4();
    }
    return 0;
}
